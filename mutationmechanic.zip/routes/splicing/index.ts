// This file is intended for backend use and should not be included in the frontend bundle.
export default {};
